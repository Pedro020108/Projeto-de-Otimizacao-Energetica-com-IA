Projeto de Análise de Consumo de Energia  

Resolução de 40 exercícios envolvendo análise exploratória, aprendizado de máquina e séries temporais com dados de consumo elétrico.  


Ambiente de Execução  

- Ambiente recomendado:  
  - Google Colab
  - Jupyter Notebook local  
- Orange Data Mining:  
  - Download: [https://orangedatamining.com/download/](https://orangedatamining.com/download/)  


Informações dos Datasets  

Dataset 1: Individual Household Electric Power Consumption 
Fonte: [UCI Machine Learning Repository](https://archive.ics.uci.edu/dataset/235/individual+household+electric+power+consumption)  

- Período: 2006 a 2010  
- Frequência: 1 registro por minuto  
- Total de registros: ~2.075.259 linhas  
- Variáveis principais:  
  - `Date` (dd/mm/yyyy) – Data da medição  
  - `Time` (hh:mm:ss) – Horário da medição  
  - `Global_active_power` (kilowatts) – Consumo total ativo da residência  
  - `Global_reactive_power` (kilowatts) – Consumo de potência reativa  
  - `Voltage` (volts) – Tensão elétrica  
  - `Global_intensity` (amperes) – Corrente global  
  - `Sub_metering_1` (watt-hora) – Consumo de cozinha (fogão, forno, etc.)  
  - `Sub_metering_2` (watt-hora) – Consumo de lavanderia  
  - `Sub_metering_3` (watt-hora) – Consumo de climatização/aquecimento  


Dataset 2: Appliances Energy Prediction 
Fonte: [UCI Machine Learning Repository](https://archive.ics.uci.edu/dataset/374/appliances+energy+prediction)  

- Período: 2006 a 2016 (medições em 10 minutos)  
- Total de registros: 19.735 linhas  
- Variáveis principais: 
  - `Appliances` – Consumo de energia (Wh)  
  - `lights` – Consumo de iluminação (Wh)  
  - Variáveis internas (temp e umidade em diferentes cômodos da casa)  
  - Variáveis externas (clima, pressão atmosférica, velocidade do vento, etc.)  



Todos os notebooks (`.ipynb`) organizados por parte  
   - Cada exercício deve estar separado em blocos de código.  
   - Resultados numéricos, tabelas e gráficos devem ser exibidos no próprio notebook.  


Critérios de Avaliação  

- [ ] Organização dos arquivos e clareza na entrega  
- [ ] Execução correta dos exercícios (resultados coerentes)  
- [ ] Aplicação das técnicas de análise de dados, estatística e machine learning  
- [ ] Qualidade das visualizações (gráficos informativos)  
- [ ] Interpretação e conclusões adequadas  
- [ ] Uso dos widgets do Orange Data Mining (parte 4)
