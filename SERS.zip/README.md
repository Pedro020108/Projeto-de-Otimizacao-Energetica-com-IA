# Projeto de Análise de Consumo de Energia

## Objetivo
Esta entrega contempla a análise de consumo energético residencial utilizando os datasets **Individual Household Electric Power Consumption** e **Appliances Energy Prediction**.  
A parte do projeto inclui **análise exploratória, aprendizado de máquina, séries temporais, normalização de dados, PCA, regressão e clustering**.  
A **Parte 4** utiliza o **Orange Data Mining** para visualização, amostragem e clustering.

---

## Datasets

### household_power_consumption.txt
- Contém medições de consumo elétrico de uma residência entre 2006 e 2010, registradas a cada minuto.  
- Variáveis principais: `Date`, `Time`, `Global_active_power`, `Global_reactive_power`, `Voltage`, `Global_intensity`, `Sub_metering_1`, `Sub_metering_2`, `Sub_metering_3`.  
- Fonte: [UCI Machine Learning Repository](https://archive.ics.uci.edu/).

### energydata_complete.csv
- Contém consumo de energia de aparelhos (**Appliances**) e variáveis ambientais (temperatura, umidade interna e externa, condicionamento).  
- Variáveis principais: `date`, `Appliances`, `lights`, `T1-T9` (temperaturas), `RH_1-RH_9` (umidade), `Press_mm_hg`, `RH_out`, `Windspeed`, `Visibility`, `Tdewpoint`, `rv1`, `rv2`.  
- Fonte: [UCI Machine Learning Repository](https://archive.ics.uci.edu/).

### Parte 3 CSV
- Pode ser o mesmo arquivo **energydata_complete.csv** ou uma versão filtrada/modificada conforme os exercícios da Parte 3.  
- Contém medições de consumo de energia e variáveis ambientais para análises de regressão, normalização e PCA.

---

## Colab - Python

- Abrir os notebooks no **Google Colab** ou **Jupyter Notebook**.  
- Cada notebook contém os exercícios separados em blocos de código.  
- Os exercícios **1 a 35** devem ser resolvidos com **Python** utilizando as bibliotecas:  
  `Pandas, Matplotlib, Seaborn, Scikit-learn e Statsmodels`.

### Instalação de dependências
```bash
pip install pandas matplotlib seaborn scikit-learn statsmodels
```

---

## Parte 4 - Orange Data Mining

1. Abrir o **Anaconda Navigator**.  
2. **Orange3** já está instalado.  
3. Abrir o **Orange** pelo Anaconda Navigator.  
4. Importar manualmente o arquivo `household_power_consumption.txt` no widget **CSV File Import**.  
   - Garantir que o caminho para o arquivo esteja correto.  
5. Seguir os widgets na ordem do workflow:  
   - **CSV File Import → Data Table**: visualizar dataset  
   - **Sample Data → Distribution**: amostra 1%  
   - **Distribution**: visualizar distribuição de `Global_active_power`  
   - **Scatter Plot**: `Voltage` versus `Global_intensity`  
   - **Select Columns → K-Means → Scatter Plot**: agrupar e visualizar clusters  

---

## Respostas Parte 4

### Exercício 36 - Importação e visualização inicial
- Número de variáveis: **9**  
- Número de registros: aproximadamente **2.075.259**  
- Visualização: primeiras **10 linhas** no Data Table

### Exercício 37 - Amostragem de dados 1%
- Tamanho da amostra: aproximadamente **20.700 registros**  
- Distribuição semelhante à base completa

### Exercício 38 - Distribuição do consumo
- Consumo concentrado em **valores baixos**  
- Presença de alguns **picos de consumo alto**  
- Distribuição **assimétrica à direita**

### Exercício 39 - Relação entre Voltage e Global_intensity
- Correlação: **fraca ou levemente negativa**  
- Visualização: **nuvem de pontos dispersa**, sem padrão linear forte

### Exercício 40 - K-Means clustering
- Número de clusters: **3**  
- Perfis médios:  
  - **Cluster 0**: baixo consumo em todos os submedidores  
  - **Cluster 1**: maior consumo em **Sub_metering_2**  
  - **Cluster 2**: maior consumo em **Sub_metering_3**  
- Visualização: **Scatter Plot colorido** mostrando padrões distintos de consumo
