
# Projeto: Energia Inteligente com Rastreamento Solar e Controle de Carga

## Visão Geral
Este projeto simula um sistema de rastreamento solar com ESP32 que orienta um painel conforme a luz solar (usando LDRs) e ativa uma carga (LED) com base no nível de energia disponível (simulado por potenciômetro).

## Funcionalidades
- Rastreamento solar com servo motor
- Simulação de nível de bateria
- Automação de carga com base na energia disponível
- Monitoramento serial dos dados

## Componentes usados (simulados via Wokwi)
- ESP32
- 2x LDR (simulam posição do Sol)
- Servo motor (simula movimentação do painel)
- Potenciômetro (simula estado da bateria)
- LED (simula uma carga residencial)

## Como executar
Acesse o projeto Wokwi: [Link do projeto Wokwi](https://wokwi.com/projects/XXXXX) *(coloque aqui após publicar)*

## Diagrama do Circuito
Veja `diagrama.png` neste repositório.

## Vídeo técnico
Acesse o vídeo de apresentação: [Link do vídeo no YouTube](https://youtube.com)

## Licença
MIT
