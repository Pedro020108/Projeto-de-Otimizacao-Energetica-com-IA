
# Roteiro para Vídeo Técnico (até 5 minutos)

## Introdução
Olá, somos o grupo responsável pelo projeto de energia inteligente com rastreamento solar e automação de carga.

## O que o sistema faz?
- O sistema detecta a luz solar usando sensores LDR
- Um servo motor ajusta a direção do "painel solar"
- Um potenciômetro simula o nível da bateria
- Um LED simula uma carga, que só liga quando há energia suficiente

## Por que isso é útil?
- Ajuda a economizar energia
- Garante uso inteligente da bateria
- Simula autonomia em caso de falha na rede elétrica

## Encerramento
Esperamos que tenham gostado da demonstração. Todos os arquivos estão no GitHub. Obrigado!
